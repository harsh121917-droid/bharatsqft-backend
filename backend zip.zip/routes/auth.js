const express = require("express");
const router  = express.Router();
const { register, login, getMe, updatePassword } = require("../controllers/authController");
const { protect } = require("../middleware/authMiddleware");

router.post("/register",         register);
router.post("/login",            login);
router.get( "/me",               protect, getMe);
router.patch("/update-password", protect, updatePassword);

module.exports = router;